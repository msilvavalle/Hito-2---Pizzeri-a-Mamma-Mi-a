import { useState } from "react";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./Home";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";

const App = () => {
  const [view, setView] = useState("home");

  return (
    <>
      <Navbar setView={setView} />
      {view === "home" && <Home />}
      {view === "login" && <LoginPage />}
      {view === "register" && <RegisterPage />}
      <Footer />
    </>
  );
};

export default App;
