// src/components/Footer.jsx

const Footer = () => {
    return (
      <footer className="bg-dark text-light text-center py-3 mt-4">
        <p className="mb-0">
          © 2021 - Pizzería Mamma Mía! - Todos los derechos reservados
        </p>
        <small>Desarrollado como Hito 1 - Introducción a React</small>
      </footer>
    );
  };
  
  export default Footer;
  