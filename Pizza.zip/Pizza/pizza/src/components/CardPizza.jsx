// src/components/CardPizza.jsx

const CardPizza = ({ name, price, ingredients, img }) => {
    const formatCurrency = (value) =>
      value.toLocaleString("es-CL", { minimumFractionDigits: 0 });
  
    return (
      <div className="card h-100">
        <img src={img} className="card-img-top" alt={name} />
        <div className="card-body d-flex flex-column">
          <h5 className="card-title">{name}</h5>
  
          <p className="fw-bold mb-1">Ingredientes:</p>
          <ul className="list-unstyled flex-grow-1">
            {ingredients.map((ing, index) => (
              <li key={index}>🟠 {ing}</li>
            ))}
          </ul>
  
          <p className="fw-bold mt-2">Precio: ${formatCurrency(price)}</p>
  
          <div className="d-flex justify-content-between mt-2">
            <button className="btn btn-outline-secondary btn-sm">
              Ver más 👀
            </button>
            <button className="btn btn-dark btn-sm">Añadir 🛒</button>
          </div>
        </div>
      </div>
    );
  };
  
  export default CardPizza;
  